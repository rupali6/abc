'''
Global Arguments
'''

import os

#maximum file size in mb
file_mb_max = 100

#encryption key
app_key = 'any_non_empty_string'

#full path destination for our uplaod video files
upload_dest = os.path.join(os.getcwd(), 'uploads_folder')

#list of allowed extensions
extensions = set(['mp4'])